document.getElementById('add-product-btn').addEventListener('click', addProduct);

function addProduct() {
    const productContainer = document.getElementById('product-container');

    const newProduct = document.createElement('div');
    newProduct.classList.add('product');

    const productImage = document.createElement('img');
    // Assurez-vous que le chemin d'accès à l'image est correct
    productImage.src = 'path-to-your-image/odaban-spray1.jpg';
    productImage.alt = 'Odaban Spray';

    const productName = document.createElement('h3');
    productName.innerText = 'Odaban Spray Antitranspirant';

    const productLink = document.createElement('a');
    productLink.href = 'https://odaban.de/collections/odaban-landingpage?sca_ref=6705152.NDMuykyWkh&utm_source=affiliate&utm_medium=affiliate&utm_campaign=affiliate';
    productLink.innerText = 'Buy Now';
    productLink.target = '_blank';

    newProduct.appendChild(productImage);
    newProduct.appendChild(productName);
    newProduct.appendChild(productLink);

    productContainer.appendChild(newProduct);
}
